#include<stdio.h>
#include<pthread.h>
#include<stdlib.h>

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

volatile int a=0;


void* func(void *data){
//  pthread_mutex_lock(&mutex);
 for(int i=0;i<10;i++){
  a++; 
    printf("loop1[%d] :%d\n",i+1,a);
}
//  pthread_mutex_unlock(&mutex);
}

void* func2(void *data){
//  pthread_mutex_lock(&mutex);
  for(int i=0;i<10;i++){
    printf("loop2[%d]:%d\n",10-i,a); 
  a--;
  }
//  pthread_mutex_unlock(&mutex);
}


int main(void){
    pthread_t t1,t2;
    
for(int i=0;i<10;i++){
    if(pthread_create(&t1,NULL,func,(void *)NULL)){exit(1);}
    if(pthread_create(&t2,NULL,func2,(void *)NULL)){exit(1);}
}    
pthread_exit(NULL);


}
