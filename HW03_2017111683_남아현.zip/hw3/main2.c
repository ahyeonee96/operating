#include<stdio.h>
#include<pthread.h>
#include<unistd.h>
#include<stdlib.h>
#include<string.h>
#include<sys/time.h>

#define MILLION 1000000


int a[2][2]={1,2,3,4}, b[2][2]={5,6,7,8}, c[2][2];


void *sing(void *data){
    c[0][0]=a[0][0]*b[0][0]+a[0][1]*b[1][0];
    c[0][1]=a[0][0]*b[0][1]+a[0][1]*b[1][1];
    c[1][0]=a[1][0]*b[0][0]+a[1][1]*b[1][0];
    c[1][1]=a[1][0]*b[0][1]+a[1][1]*b[1][1];
}

void *multi1(void *data){
    c[0][0]=a[0][0]*b[0][0]+a[0][1]*b[1][0];
    c[0][1]=a[0][0]*b[0][1]+a[0][1]*b[1][1];
}

void *multi2(void *data){
    c[1][0]=a[1][0]*b[0][0]+a[1][1]*b[1][0];
    c[1][1]=a[1][0]*b[0][1]+a[1][1]*b[1][1];
}

int main(){
   
    struct timeval tpstart, tpend;
    long timediff;
    int i;
   
    pthread_t t1,t2;
    char str[10];

    
    
    printf("----matrix calculation----\n");
    while(1){
    printf("<press 1 or 2>\t1. single \t2. multi\t3. stop\n");
    gets(str);
        
        if(!strcmp("1",str)){
    gettimeofday(&tpstart, NULL);
            if(pthread_create(&t1,NULL,sing,(void *)NULL)){exit(0);}
            gettimeofday(&tpend, NULL);
            sleep(1);
        }else if(!strcmp("2",str)){
             gettimeofday(&tpstart, NULL);
            if(pthread_create(&t1,NULL,multi1,(void *)NULL)){exit(0);}
            if(pthread_create(&t2,NULL,multi2,(void *)NULL)){exit(0);}
            gettimeofday(&tpend, NULL);
            sleep(1);
        }else if(!strcmp("3",str)){
            break;
        }else printf("1 or 2 please\n");

timediff = MILLION*(tpend.tv_sec - tpstart.tv_sec) + tpend.tv_usec - tpstart.tv_usec;

    printf("%d %d\n%d %d\n",c[0][0],c[0][1],c[1][0],c[1][1]);
    printf("it took %ld usec\n",timediff);
}}
