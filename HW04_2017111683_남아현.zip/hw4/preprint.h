#include<stdio.h>

int prepend(char *buf,unsigned offset, char *new_str);
int preprintf(char *buf, unsigned offset, char *format, ...);
void RecursiveRoutine(int RecursiveDepth);
char *commas(unsigned long amount);
int heapheap();
