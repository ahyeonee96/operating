#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"preprint.h"
#include<pthread.h>

    unsigned long FirstStackLocation;


void main(){
    
    int test,test2;
    int topofstack;

    printf("<<This is memory segment test>>\n");
    printf("1. HEAP\n2. STACK\n");
    scanf("%d",&test2);

    
    if(test2==1){
        heapheap();
    
    }else if(test2==2){
    FirstStackLocation = (unsigned long)(&topofstack);
    printf("FIrst location on stack : %s\n",commas((unsigned long)FirstStackLocation));
    RecursiveRoutine(0);
   }

}

