#include<stdio.h>
#include<string.h>
#include<stdarg.h>
#include<stdlib.h>
#define ONE_MEG 1048576
#define STACK_ALLOC ONE_MEG/20
#define BASE 16
#define GROUP 4
#define MAXTEXT 25

    int NumOfAllo =0;
    long *MemoryPtr;
    unsigned long FirstStackLocation;


int prepend(char *buf, unsigned offset, char *new_str){
    int new_len = strlen(new_str);
    int new_start = offset - new_len;

    if(new_start >= 0)
        memcpy(buf+new_start,new_str,new_len);

    return new_start;

}

int preprintf(char *buf,unsigned offset, char *format, ...){
    int pos =offset;
    char *temp = malloc(BUFSIZ);

    if(temp){
        va_list args;

        va_start(args,format);
        vsprintf(temp,format,args);
        pos=prepend(buf,offset,temp);
        va_end(args);
        free(temp);
    
    }
    return pos;
}

void RecursiveRoutine(int RecursiveDepth){
    char Temp[STACK_ALLOC];
    char StringTop[32];
    char StringBottom[32];

    printf("Iteration = %3d : Stack Bytes : %ld\n", RecursiveDepth,FirstStackLocation - (unsigned long)&(Temp[STACK_ALLOC]));
    RecursiveDepth++;


    RecursiveRoutine(RecursiveDepth);
}


char *commas(unsigned long amount){
    short i;
    short offset = MAXTEXT -1;
    short place;

    static char text[MAXTEXT];

    for(i=0;i<MAXTEXT;i++)
        text[i]='\0';

    for(place=0;amount >0;++place){
        if(place%GROUP ==0 && place >0)
            offset = prepend(text,offset,",");

        offset = preprintf(text,offset,"%X",amount %BASE);
        amount/=BASE;
    }

    return (offset >=0) ? text+offset : NULL;
}


int heapheap(){
    long NumberOfAllocations =0;

    
    while(1){
    MemoryPtr = (long *)malloc(ONE_MEG);
    if(MemoryPtr == NULL ){
        printf("The program ends. NO MORE MEMORY");
        printf("Total megabytes allocated = %ld\n",NumberOfAllocations);
    exit(0);
    }
    NumberOfAllocations++;
    if((NumberOfAllocations % 100)==0)
    printf("We have allocated %ld megabytes\n",NumberOfAllocations);

    }
}
