#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>
#include<string.h>
#include<sys/ioctl.h>
#define MAX_SIZE 200

int main(void){
    int fd;

    char* in=(char*)malloc(sizeof(char) *MAX_SIZE);
    char* out=(char*)malloc(sizeof(char) *MAX_SIZE);
    if((fd=open("/dev/mydevicefile",O_RDWR))<0){
        perror("open error");
        return -1;
    }
    strcpy(out, "abcdefghijklmnopqrstuvwxyz");
    write(fd,out,MAX_SIZE);
    strcpy(out, "zyxwvutsrqponmlkjihgfedcba");
    write(fd,out,MAX_SIZE);
    strcpy(out, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
    write(fd,out,MAX_SIZE);
    strcpy(out, "ZYXWVUTSRQPONMLKJIHGFEDCBA");
    write(fd,out,MAX_SIZE);
    
    read(fd,in,MAX_SIZE); printf("%s\n",in);
    read(fd,in,MAX_SIZE); printf("%s\n",in);
    read(fd,in,MAX_SIZE); printf("%s\n",in);
    read(fd,in,MAX_SIZE); printf("%s\n",in);

    free(in);
    free(out);

    close(fd);
    return 0;
}
