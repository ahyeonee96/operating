#include<stdio.h>
#include<unistd.h>
#include<stdlib.h>
#include<sys/wait.h>
#include "instructions.h"

int ls(){
    int pid, status;
    char* argv[] = {"ls",0};
    pid=fork();

    switch (pid){
    case -1:
        printf("fork error \n");
        exit(1);

    case 0:
        execv("/bin/ls",argv);
        printf("exec error \n");
        exit(1);

    default:
        wait(&status);
    }


    return 0;
    
}
