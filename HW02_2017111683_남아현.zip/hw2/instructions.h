int pwd();
int ls();
int ls_al();
