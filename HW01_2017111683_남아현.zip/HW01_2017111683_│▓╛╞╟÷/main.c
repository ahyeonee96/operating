#include"hw1.h"

void main(){
	int i;
	char line[]="1 2 3 4 5";
	char line2[]="1 2 3 4 5";
	STACK* stack = create_stack();
	QUEUE* queue = create_queue();

	printf("input:");
	for(i=0;i<10;i++){printf("%c",line[i]);}

	strtok_stack(stack,line); //output of stack
	strtok_queue(queue,line2); //output of queue
	printf("\n");		
}


