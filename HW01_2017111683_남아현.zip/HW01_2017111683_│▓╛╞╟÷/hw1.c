#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"hw1.h"


//start stack ft
STACK* create_stack(){
	STACK* stack=(STACK*)malloc(sizeof(STACK));
	stack->count=0;
	stack->top=NULL;
	return stack;
}

void push(STACK* stack,char a){
	NODE* node=(NODE*)malloc(sizeof(NODE));
	if(node==NULL) printf("%c can not be inserted",a);

	else{//if node!=NULL
		if(stack->count==0){
			stack->top=node;
			node->data=a;
		}else{
			node->next=stack->top;
			stack->top=node;
			node->data=a;
		}	
	(stack->count)++;
	}
}

char pop(STACK* stack){
	NODE* temp;
	char a=stack->top->data;

	if(stack->count==0){
		printf("there's no NODE in STACK.");
	}else{
		temp=stack->top;	
		stack->top=stack->top->next;
		free(temp);
		(stack->count)--;
		return a;
	}

}

//end stack ft

//start queue ft
QUEUE* create_queue(){
	QUEUE* queue=(QUEUE*)malloc(sizeof(QUEUE));
	queue->count=0;
	queue->head=NULL;
	queue->tail=NULL;
	return queue;
}


void enqueue(QUEUE* queue,char a){
	NODE* node=(NODE*)malloc(sizeof(NODE));
	if(node==NULL){printf("node can not be inserted.\n");
	}else{
		if(queue->count==0){
			queue->head=node;
			queue->tail=node;
			node->next=NULL;
			node->data=a;
		}else{
			queue->tail->next=node;
			queue->tail=node;
			node->next=NULL;
			node->data=a;
		}

	(queue->count)++;
	}
}

char dequeue(QUEUE* queue){
	char b=queue->head->data;
	NODE* temp;

	if(queue->count==0){
		printf("there's no node in the queue.");
	}else{
		temp=queue->head;
		queue->head=temp->next;
		free(temp);	
		(queue->count)--;
		return b;
	}
}

void strtok_stack(STACK* stack,char line[]){
	char* result;
	result=strtok(line," ");
	while(result!=NULL){
		push(stack,' ');

		push(stack,*result);
		result=strtok(NULL," ");
	}

	printf("\nstack output:");
	while(stack->count!=0){
		printf("%c",pop(stack));
	}
}

void strtok_queue(QUEUE* queue,char line[]){
	char* result;
	result=strtok(line," ");
	while(result!=NULL){
		enqueue(queue,*result);
		result=strtok(NULL," ");

		enqueue(queue,' ');
	}

	printf("\nqueue output:");
	while(queue->count!=0){
		printf("%c",dequeue(queue));
	}
}
