#include<stdio.h>

typedef struct node{
	char data;
	struct node* next;	
}NODE;

typedef struct stack{
	int count;
	NODE* top;
}STACK;

typedef struct queue{
	int count;
	NODE* head;
	NODE* tail;
}QUEUE;



STACK* create_stack();
void push(STACK* stack,char a);
char pop(STACK* stack);

QUEUE* create_queue();
void enqueue(QUEUE* queue,char a);
char dequeue(QUEUE* queue);

void strtok_stack(STACK* stack,char line[]);
void strtok_queue(QUEUE* queue,char line[]);
